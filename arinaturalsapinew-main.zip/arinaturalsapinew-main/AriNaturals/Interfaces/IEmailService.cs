﻿namespace AriNaturals.Interfaces
{
    public interface IEmailService
    {
        Task SendEmailAsync(string to, string subject, string body);
        Task<string> GenerateOrderEmail(string customerName,
                                        List<(string ItemName, string Measurement, int Quantity, decimal UnitPrice, string ImageUrl)> items,
                                        string shippingAddress);
    }
}
