﻿namespace AriNaturals.Interfaces
{
    public interface IOtpService
    {
        Task GenerateAndSendOtpAsync(string email, int length = 6, int expiryMinutes = 5);
        Task<bool> ValidateOtpAsync(string email, string otp);
    }
}
