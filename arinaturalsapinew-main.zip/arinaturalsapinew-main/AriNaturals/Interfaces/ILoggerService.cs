﻿namespace AriNaturals.Interfaces
{
    public interface ILoggerService
    {
        Task LogAsync(Exception ex, string infoMessage = null, LogLevel logLevel = LogLevel.Error);
    }
}
