﻿namespace AriNaturals.Entity
{
    public class ErrorLog
    {
        public int Id { get; set; }
        public string Message { get; set; }
        public string StackTrace { get; set; }
        public string Source { get; set; }
        public string InnerException { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public string LogLevel { get; set; }
        public string ControllerName { get; set; }
    }

}
