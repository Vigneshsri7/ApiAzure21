﻿using Microsoft.AspNetCore.Identity;

namespace AriNaturals.Entity
{
    public class ApplicationUser : IdentityUser
    {
        public bool IsEmailVerified { get; set; } = false;
        public Customer? Customer { get; set; }
    }
}
