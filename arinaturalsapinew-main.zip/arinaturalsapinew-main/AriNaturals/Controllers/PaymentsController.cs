﻿using AriNaturals.DataAccess;
using AriNaturals.Entity;
using AriNaturals.Interfaces;
using AriNaturals.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AriNaturals.Controllers
{
    [Authorize]
    public class PaymentsController : Controller
    {
        #region Field(s)
        private readonly IConfiguration _config;
        private readonly IEmailService _emailService;
        private readonly IRazorPayService _razorPayService;
        private readonly AppDbContext _context;
        private readonly ILoggerService _LoggerService;
        #endregion

        #region Constructor
        public PaymentsController(IConfiguration config, IEmailService emailService, IRazorPayService razorPayService, AppDbContext context, ILoggerService LoggerService)
        {
            _config = config;
            _emailService = emailService;
            _razorPayService = razorPayService;
            _context = context;
            _LoggerService = LoggerService;
        }
        #endregion

        #region Method(s)
        [HttpPost("verify-payment")]
        public async Task<IActionResult> VerifyPayment([FromBody] VerifyPaymentRequest request)
        {
            try
            {
                await _LoggerService.LogAsync(null, $"Payment Verification Started for the Order Id: {request.OrderId}", LogLevel.Information);
                var razorPayPaymentInfo = _razorPayService.VerifyPayment(request.RazorpayOrderId, request.RazorpayPaymentId, request.RazorpaySignature);
                if (razorPayPaymentInfo == null)
                    return BadRequest("Invalid signature. Payment verification failed.");

                var payment = new Payment
                {
                    RazorpayPaymentId = request.RazorpayPaymentId,
                    RazorpayOrderId = razorPayPaymentInfo["order_id"],
                    RazorpaySignature = request.RazorpaySignature,
                    Status = razorPayPaymentInfo["status"],
                    Method = razorPayPaymentInfo["method"],
                    Amount = razorPayPaymentInfo["amount"] / 100M,
                    Currency = razorPayPaymentInfo["currency"],
                    Email = razorPayPaymentInfo["email"],
                    Contact = razorPayPaymentInfo["contact"],
                    OrderId = request.OrderId
                };

                _context.Payments.Add(payment);
                await _context.SaveChangesAsync();

                if (payment.Status.ToLower() == "captured")
                {
                    await _LoggerService.LogAsync(null, $"Payment Verification completed for the Order Id: {request.OrderId}", LogLevel.Information);
                    
                    var order = _context.Orders.Include(o => o.OrderItems).ThenInclude(oi => oi.Variant).ThenInclude(v => v.Product).ThenInclude(p => p.Images).Where(o => o.OrderId == payment.OrderId).FirstOrDefault();
                    order.Status = "Ordered";
                    _context.Orders.Update(order);
                    await _context.SaveChangesAsync();

                    await _LoggerService.LogAsync(null, $"Payment information updated for the Order Id: {request.OrderId}", LogLevel.Information);


                    var customer = await _context.Customers
                                        .Include(c => c.Addresses)
                                        .FirstOrDefaultAsync(c => c.CustomerId == order.CustomerId);

                    var orderItemsList = order.OrderItems.Select(oi => (
                        Name: oi.Product.Title,
                        Variant: oi.Variant.VariantName ?? "",
                        Qty: oi.Quantity,
                        Price: oi.UnitPrice,
                        ImageUrl: oi.Product.Images.FirstOrDefault()?.ImageUrl ?? ""
                    )).ToList();

                    var shippingAddress = customer.Addresses
                        .Where(a => a.IsDefault)
                        .Select(a => $"{customer.FullName}\n{a.AddressLine1}\n{a.City}, {a.State} {a.PostalCode}\n{a.Country}")
                        .FirstOrDefault() ?? "No address found";

                    await _LoggerService.LogAsync(null, $"Confirmation email is being triggered for the order: {request.OrderId}", LogLevel.Information);

                    var htmlBody = await _emailService.GenerateOrderEmail(
                        customer.FullName,
                        orderItemsList,
                        shippingAddress
                    );

                    string subject = $"Ordered: {orderItemsList.Count} item. Thanks for shopping with us";
                    await _emailService.SendEmailAsync(customer.Email, subject, htmlBody);

                    await _LoggerService.LogAsync(null, $"Email sent Successfully for the Order Id: {request.OrderId}", LogLevel.Information);
                }

                return Ok(new { Eamil = payment.Email, Amount = payment.Amount, status = payment.Status });
            }
            catch(Exception ex)
            {
                await _LoggerService.LogAsync(ex, null, LogLevel.Error);
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occured while verifying payment information for order id: {request.OrderId}");
            }
        }

        [HttpPost("Send-email")]
        public async Task<IActionResult> SendEmail([FromBody] string toemail)
        {
            await _emailService.SendEmailAsync("engautomata@gmail.com", "Payment success", "Payment verification success.");
            return Ok();
        }
        #endregion
    }
}
