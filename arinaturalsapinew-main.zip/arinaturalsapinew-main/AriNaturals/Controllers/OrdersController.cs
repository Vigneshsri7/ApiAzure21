﻿using AriNaturals.DataAccess;
using AriNaturals.DTOs;
using AriNaturals.Entity;
using AriNaturals.Interfaces;
using AriNaturals.Utilities;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Authorize]
[ApiController]
[Route("api/[controller]")]
public class OrdersController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;
    private readonly IRazorPayService _razorPayService;
    private readonly ILoggerService _LoggerService;

    public OrdersController(AppDbContext context, IMapper mapper, IRazorPayService razorPayService, ILoggerService LoggerService)
    {
        _context = context;
        _mapper = mapper;
        _razorPayService = razorPayService;
        _LoggerService = LoggerService;
    }

    [HttpGet("{orderNo}")]
    public async Task<ActionResult<OrderDto>> GetOrder(string orderNo)
    {
        try
        {
            var order = await _context.Orders
                .Include(o => o.Customer)
                .Include(o => o.ShippingAddress)
                .Include(o => o.Payments)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(o => o.OrderNumber == orderNo);

            if (order == null)
                return Ok("Order not found for the given order number.");

            return _mapper.Map<OrderDto>(order);
        }
        catch (Exception ex)
        {
            await _LoggerService.LogAsync(ex, null, LogLevel.Error);
            return StatusCode(StatusCodes.Status500InternalServerError, $"An error occured while fetching order for order id: {orderNo}.");
        }
    }

    [HttpGet("{customerId}")]
    public async Task<ActionResult<List<OrderDto>>> GetOrdersByUser(Guid customerId)
    {
        try
        {
            var orders = await _context.Orders
                .Include(o => o.Customer)
                .Include(o => o.ShippingAddress)
                .Include(o => o.Payments)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Product)
                .Where(o => o.CustomerId == customerId)
                .ToListAsync();

            if (!orders.Any())
                return Ok("Order not found for the given order id.");

            return _mapper.Map<List<OrderDto>>(orders);
        }
        catch (Exception ex)
        {
            await _LoggerService.LogAsync(ex, null, LogLevel.Error);
            return StatusCode(StatusCodes.Status500InternalServerError, "An error occured while fetching customer orders.");
        }
    }

    [HttpGet("GetCustomerOrders")]
    public async Task<ActionResult<List<OrderDto>>> GetCustomerOrders()
    {
        try
        {
            var userId = User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value;

            var orders = await _context.Orders
                                     .Include(o => o.Customer)
                                     .Include(o => o.ShippingAddress)
                                     .Include(o => o.Payments)
                                     .Include(o => o.OrderItems)
                                         .ThenInclude(oi => oi.Product)
                                         .ThenInclude(oi => oi.Images)
                                     .Include(o => o.OrderItems)
                                         .ThenInclude(oi => oi.Variant)
                                     .Where(o => o.Customer.ApplicationUserId == userId)
                                     .ToListAsync();

            if (!orders.Any())
                return Ok("Order not found for the given order id.");

            return _mapper.Map<List<OrderDto>>(orders);
        }
        catch (Exception ex)
        {
            await _LoggerService.LogAsync(ex, null, LogLevel.Error);
            return StatusCode(StatusCodes.Status500InternalServerError, "An error occured while fetching customer orders.");
        }
    }

    [HttpPost]
    public async Task<ActionResult<OrderDto>> CreateOrder([FromBody] CreateOrderRequest request)
    {
        if (!ModelState.IsValid)
            return BadRequest("Invalid request. Please check the request before proceeding");

        if(request.Items.Any() && request.Items.Any(it => it.VariantId == Guid.Empty))
        {
            return BadRequest("Invalid request. Please add variant of the product to proceed further.");
        }

        using var transaction = await _context.Database.BeginTransactionAsync();
        try
        {
            var customer = await _context.Customers
                        .FirstOrDefaultAsync(c => c.Email == request.CustomerEmail);

            Address shippingAddress = null, billingAddress = null;

            if (request.ShippingAddress != null)
            {
                shippingAddress = _mapper.Map<Address>(request.ShippingAddress);
                shippingAddress.CustomerId = customer.CustomerId;
                _context.Addresses.Add(shippingAddress);
            }

            if (request.IsBillingSameAsShipping)
            {
                billingAddress = shippingAddress;
            }
            else if (request.BillingAddress != null)
            {
                billingAddress = _mapper.Map<Address>(request.BillingAddress);
                billingAddress.CustomerId = customer.CustomerId;
                _context.Addresses.Add(billingAddress);
            }

            await _context.SaveChangesAsync();

            var lastOrder = await _context.Orders.OrderByDescending(o => o.OrderSequence).FirstOrDefaultAsync();
            var nextId = (lastOrder?.OrderSequence ?? 0) + 1;

            var order = new AriNaturals.Entity.Order
            {
                CustomerId = customer.CustomerId,
                OrderNumber = Tools.GenerateOrderNumber(nextId),
                BillingAddressId = (Guid)(billingAddress?.AddressId ?? shippingAddress?.AddressId),
                ShippingAddressId = (Guid)(shippingAddress?.AddressId ?? billingAddress?.AddressId),
                AddressType = request.IsBillingSameAsShipping ? "Both" : "Separate",
                Status = "Pending",
                ShippingStatus = "Processing",
                CreatedAt = DateTime.UtcNow,
                OrderSequence = nextId,
                TotalAmount = request.Items.Sum(oi => oi.Quantity * oi.UnitPrice),
                RazorPayOrderId = string.Empty
            };

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            var razorpayOrderId = await _razorPayService.CreateOrderAsync(order.TotalAmount, order.OrderNumber);

            // 3. Update order with Razorpay Order Id
            order.RazorPayOrderId = razorpayOrderId;
            _context.Orders.Update(order);
            await _context.SaveChangesAsync();

            // 4. Add OrderItems linked to the OrderId
            foreach (var item in request.Items)
            {
                var orderItem = new OrderItem
                {
                    OrderItemId = Guid.NewGuid(),
                    OrderId = order.OrderId,
                    ProductId = item.ProductId,
                    VariantId = item.VariantId,
                    Quantity = item.Quantity,
                    UnitPrice = item.UnitPrice,
                    TotalPrice = item.Quantity * item.UnitPrice,
                };

                _context.OrderItems.Add(orderItem);
            }

            await _context.SaveChangesAsync();
            await transaction.CommitAsync();

            var orderDto = _mapper.Map<OrderDto>(order);

            return CreatedAtAction(nameof(CreateOrder), new { OrderInfo = orderDto });
        }
        catch (Exception ex)
        {
            await transaction.RollbackAsync();
            await _LoggerService.LogAsync(ex, null, LogLevel.Error);
            return StatusCode(StatusCodes.Status500InternalServerError, "Order creation failed due to Razorpay error");
        }
    }

}
