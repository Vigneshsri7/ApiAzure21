﻿using AriNaturals.DataAccess;
using AriNaturals.DTOs;
using AriNaturals.Entity;
using AriNaturals.Interfaces;
using AriNaturals.Models;
using AriNaturals.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AriNaturals.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly IOtpService _otpService;
        private readonly JwtTokenService _jwtService;
        private readonly AppDbContext _context;
        private readonly ILoggerService _LoggerService;

        public AccountController(
            UserManager<ApplicationUser> userManager,
            SignInManager<ApplicationUser> signInManager,
            IOtpService otpService,
            JwtTokenService jwtService,
            AppDbContext context,
            ILoggerService LoggerService)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _otpService = otpService;
            _jwtService = jwtService;
            _context = context;
            _LoggerService = LoggerService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Models.RegisterRequest request)
        {
            try
            {
                var user = new ApplicationUser { UserName = request.Email, Email = request.Email };
                var existing = await _userManager.FindByEmailAsync(request.Email);
                if (existing != null)
                {
                    if (existing.IsEmailVerified)
                    {
                        return BadRequest("Email already in use.");
                    }
                    else
                    {
                        await _otpService.GenerateAndSendOtpAsync(user.Email);
                    }
                }
                else
                {
                    var create = await _userManager.CreateAsync(user, request.Password);
                    if (!create.Succeeded) return BadRequest(create.Errors);

                    var customer = new Customer
                    {
                        ApplicationUserId = user.Id,
                        Email = user.Email,
                        FullName = user.Email
                    };

                    _context.Customers.Add(customer);
                    await _context.SaveChangesAsync();
                    await _otpService.GenerateAndSendOtpAsync(user.Email);
                }

                // optionally assign roles here            
                return Ok("Registered. Verify email via OTP sent.");
            }
            catch (Exception ex)
            {
                await _LoggerService.LogAsync(ex, null, LogLevel.Error);
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occured while registering user : {request.Email}.");
            }
        }

        [HttpPost("verify-email")]
        public async Task<IActionResult> VerifyEmail([FromBody] OtpVerifyRequest request)
        {
            try
            {
                var user = await _userManager.FindByEmailAsync(request.Email);
                if (user == null) return Ok("User not found");

                bool ok = await _otpService.ValidateOtpAsync(request.Email, request.Otp);
                if (!ok) return BadRequest("Invalid or expired OTP");

                user.IsEmailVerified = true;
                await _userManager.UpdateAsync(user);
                return Ok("Email verified.");
            }
            catch (Exception ex)
            {
                await _LoggerService.LogAsync(ex, null, LogLevel.Error);
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occured while verifying email: {request.Email}.");
            }
        }

        // Step 1 of login: check credentials, then send OTP for 2FA
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Models.LoginRequest req)
        {
            try
            {
                var user = await _userManager.FindByEmailAsync(req.Email);
                if (user == null) return BadRequest("Invalid credentials.");

                // Check password
                var passwdCheck = await _signInManager.CheckPasswordSignInAsync(user, req.Password, lockoutOnFailure: true);
                if (!passwdCheck.Succeeded) return BadRequest("Invalid credentials or account locked.");

                if (!user.IsEmailVerified) return BadRequest("Email not verified.");

                // generate OTP for 2FA
                await _otpService.GenerateAndSendOtpAsync(user.Email);
                return Ok("OTP sent to email. Verify to complete login.");
            }
            catch (Exception ex)
            {
                await _LoggerService.LogAsync(ex, null, LogLevel.Error);
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occured while login: {req.Email}.");
            }
        }

        // Step 2: verify OTP — issue JWT
        [HttpPost("verify-login-otp")]
        public async Task<IActionResult> VerifyLoginOtp([FromBody] OtpVerifyRequest req)
        {
            try
            {
                var user = await _userManager.FindByEmailAsync(req.Email);
                if (user == null) return Ok("User not found");

                bool ok = await _otpService.ValidateOtpAsync(req.Email, req.Otp);
                if (!ok) return BadRequest("Invalid or expired OTP.");

                var token = await _jwtService.GenerateTokenAsync(user);
                return Ok(new { token });
            }
            catch (Exception ex)
            {
                await _LoggerService.LogAsync(ex, null, LogLevel.Error);
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occured while verifying login: {req.Email}.");
            }
        }

        [HttpPost("forgot-password")]
        public async Task<IActionResult> ForgotPassword(string email)
        {
            try
            {
                var user = await _userManager.FindByEmailAsync(email);
                if (user == null)
                    return Ok("If the email exists, OTP has been sent.");

                await _otpService.GenerateAndSendOtpAsync(user.Email, 6, 10);

                return Ok("OTP sent to your email.");
            }
            catch (Exception ex)
            {
                await _LoggerService.LogAsync(ex, null, LogLevel.Error);
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occured while sending OTP: {email}.");
            }
        }

        [HttpPost("verify-reset-otp")]
        public async Task<IActionResult> VerifyResetOtp([FromBody] OtpVerifyRequest req)
        {
            var user = await _userManager.FindByEmailAsync(req.Email);
            if (user == null)
                return BadRequest("Invalid email.");

            var otpRecord = await _context.UserOtps
                .Where(o => o.Email == req.Email && o.OtpCode == req.Otp && !o.IsUsed)
                .OrderByDescending(o => o.ExpiryTime)
                .FirstOrDefaultAsync();

            if (otpRecord == null)
                return BadRequest("Invalid OTP.");

            if (otpRecord.ExpiryTime < DateTime.UtcNow)
                return BadRequest("OTP has expired.");

            otpRecord.IsUsed = true;
            await _context.SaveChangesAsync();

            return Ok("OTP verified. You may now reset your password.");
        }

        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword(ResetPasswordDto req)
        {
            try
            {
                var user = await _userManager.FindByEmailAsync(req.Email);
                if (user == null)
                    return BadRequest("Invalid email.");

                // allow reset only if OTP was successfully validated
                var otpRecord = await _context.UserOtps
                    .Where(o => o.Email == req.Email && o.IsUsed)
                    .OrderByDescending(o => o.ExpiryTime)
                    .FirstOrDefaultAsync();

                if (otpRecord == null)
                    return BadRequest("OTP not verified.");

                var resetResult = await _userManager.RemovePasswordAsync(user);
                if (!resetResult.Succeeded)
                    return BadRequest(resetResult.Errors);

                resetResult = await _userManager.AddPasswordAsync(user, req.NewPassword);
                if (!resetResult.Succeeded)
                    return BadRequest(resetResult.Errors);

                // Optional: clean old OTPs
                _context.UserOtps.Remove(otpRecord);
                await _context.SaveChangesAsync();

                return Ok("Password reset successful.");
            }
            catch (Exception ex)
            {
                await _LoggerService.LogAsync(ex, null, LogLevel.Error);
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occured resetting password: {req.Email}.");
            }
        }

    }

}
