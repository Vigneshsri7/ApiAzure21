﻿using System.Text.Json;
using AriNaturals.DataAccess;
using AriNaturals.DTOs;
using AriNaturals.Entity;
using AriNaturals.Interfaces;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[AllowAnonymous]
[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly IMapper _mapper;
    private readonly ILoggerService _LoggerService;

    public ProductsController(AppDbContext context, IMapper mapper, ILoggerService LoggerService)
    {
        _context = context;
        _mapper = mapper;
        _LoggerService = LoggerService;
    }

    [HttpGet]
    public async Task<ActionResult<ProductDto>> GetProducts()
    {
        try
        {
            var products = await _context.Products
                .Include(p => p.Variants)
                .Include(p => p.Images)
                .Include(p => p.Highlights)
                .ThenInclude(p => p.HighlightSections)
                .ToListAsync();

            if (!products.Any())
                return Ok();

            var productsList = _mapper.Map<List<ProductDto>>(products);
            return Ok(productsList);
        }
        catch (Exception ex)
        {
            await _LoggerService.LogAsync(ex, null, LogLevel.Error);
            return StatusCode(StatusCodes.Status500InternalServerError, $"An error occured while getting products list.");
        }
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<ProductDto>> GetProduct(Guid id)
    {
        try
        {
            var product = await _context.Products
                .Include(p => p.Variants)
                .Include(p => p.Images)
                .Include(p => p.Highlights)
                .ThenInclude(p => p.HighlightSections)
                .FirstOrDefaultAsync(p => p.ProductId == id);

            if (product == null)
                return Ok();

            return _mapper.Map<ProductDto>(product);
        }
        catch (Exception ex)
        {
            await _LoggerService.LogAsync(ex, null, LogLevel.Error);
            return StatusCode(StatusCodes.Status500InternalServerError, $"An error occured while fetching product for product id: {id}.");
        }
    }

    [HttpPost]
    public async Task<ActionResult<ProductDto>> CreateProduct(ProductDto productDto)
    {
        try
        {
            var product = _mapper.Map<Product>(productDto);
            product.ProductId = Guid.NewGuid();

            if (product.Variants != null)
            {
                foreach (var variant in product.Variants)
                    variant.ProductId = product.ProductId;
            }
            else
            {
                return BadRequest("Variants cannot be empty");
            }

            if (product.Images != null)
            {
                foreach (var image in product.Images)
                    image.ProductId = product.ProductId;
            }
            else
            {
                return BadRequest("Images cannot be empty");
            }

            if (product.Highlights != null)
            {
                foreach (var highlight in product.Highlights)
                {
                    highlight.ProductId = product.ProductId;
                    if (highlight.HighlightSections != null)
                    {
                        foreach (var section in highlight.HighlightSections)
                        {
                            section.PointsJson = JsonSerializer.Serialize(section.SectionPoints);
                        }
                    }
                }
            }
            else
            {
                return BadRequest("Highlights cannot be empty");
            }

            // Add and save
            _context.Products.Add(product);
            await _context.SaveChangesAsync();

            var createdProduct = _mapper.Map<ProductDto>(product);

            return CreatedAtAction(nameof(GetProduct), new { id = product.ProductId }, createdProduct);
        }
        catch (Exception ex)
        {
            await _LoggerService.LogAsync(ex, null, LogLevel.Error);
            return StatusCode(StatusCodes.Status500InternalServerError, $"An error occured while adding new product.");
        }
    }

    [HttpPut("{productId}/variants")]
    public async Task<IActionResult> UpdateProductVariants(Guid productId, [FromBody] List<ProductVariantDto> variantsDto)
    {
        var product = await _context.Products
            .Include(p => p.Variants)
            .FirstOrDefaultAsync(p => p.ProductId == productId);

        if (product == null)
            return Ok();

        // Remove deleted variants
        var dtoIds = variantsDto.Select(v => v.VariantId).ToList();
        foreach (var existing in product.Variants.ToList())
        {
            if (!dtoIds.Contains(existing.VariantId))
                _context.ProductVariants.Remove(existing);
        }

        // Add or update variants
        foreach (var variantDto in variantsDto)
        {
            var existing = product.Variants.FirstOrDefault(v => v.VariantId == variantDto.VariantId);
            if (existing != null)
                _mapper.Map(variantDto, existing);
            else
                product.Variants.Add(_mapper.Map<ProductVariant>(variantDto));
        }

        await _context.SaveChangesAsync();
        return Ok();
    }

    [HttpPut("{productId}/images")]
    public async Task<IActionResult> UpdateProductImages(Guid productId, [FromBody] List<ProductImageDto> imagesDto)
    {
        var product = await _context.Products
            .Include(p => p.Images)
            .FirstOrDefaultAsync(p => p.ProductId == productId);

        if (product == null)
            return Ok();

        var dtoIds = imagesDto.Select(i => i.ImageId).ToList();
        foreach (var existing in product.Images.ToList())
        {
            if (!dtoIds.Contains(existing.ImageId))
                _context.ProductImages.Remove(existing);
        }

        foreach (var imageDto in imagesDto)
        {
            var existing = product.Images.FirstOrDefault(i => i.ImageId == imageDto.ImageId);
            if (existing != null)
                _mapper.Map(imageDto, existing);
            else
                product.Images.Add(_mapper.Map<ProductImage>(imageDto));
        }

        await _context.SaveChangesAsync();
        return Ok();
    }


    [HttpPut("{productId}/highlights")]
    public async Task<IActionResult> UpdateProductHighlights(Guid productId, [FromBody] List<ProductHighlightDto> highlightsDto)
    {
        var product = await _context.Products
            .Include(p => p.Highlights)
                .ThenInclude(h => h.HighlightSections)
            .FirstOrDefaultAsync(p => p.ProductId == productId);

        if (product == null)
            return Ok();

        var dtoIds = highlightsDto.Select(h => h.HighlightId).ToList();
        foreach (var existing in product.Highlights.ToList())
        {
            if (!dtoIds.Contains(existing.HighlightId))
                _context.ProductHighlights.Remove(existing);
        }

        foreach (var highlightDto in highlightsDto)
        {
            var existing = product.Highlights.FirstOrDefault(h => h.HighlightId == highlightDto.HighlightId);
            if (existing != null)
            {
                _mapper.Map(highlightDto, existing);

                var sectionIds = highlightDto.HighlightSections.Select(s => s.SectionId).ToList();

                // Remove deleted sections
                foreach (var section in existing.HighlightSections.ToList())
                {
                    if (!sectionIds.Contains(section.SectionId))
                        _context.ProductHighlightSection.Remove(section);
                }

                // Add or update sections
                foreach (var sectionDto in highlightDto.HighlightSections)
                {
                    var existingSection = existing.HighlightSections
                        .FirstOrDefault(s => s.SectionId == sectionDto.SectionId);
                    if (existingSection != null)
                        _mapper.Map(sectionDto, existingSection);
                    else
                        existing.HighlightSections.Add(_mapper.Map<ProductHighlightSection>(sectionDto));
                }
            }
            else
            {
                var newHighlight = _mapper.Map<ProductHighlight>(highlightDto);
                newHighlight.HighlightSections = highlightDto.HighlightSections
                    .Select(s => _mapper.Map<ProductHighlightSection>(s))
                    .ToList();
                product.Highlights.Add(newHighlight);
            }
        }

        await _context.SaveChangesAsync();
        return Ok();
    }

    [HttpPut("{productId}/reviews")]
    public async Task<IActionResult> UpdateProductReviews(Guid productId, [FromBody] List<ProductReviewDto> reviewsDto)
    {
        var product = await _context.Products
            .Include(p => p.Reviews)
            .FirstOrDefaultAsync(p => p.ProductId == productId);

        if (product == null)
            return Ok();

        var dtoIds = reviewsDto.Select(r => r.ReviewId).ToList();
        foreach (var existing in product.Reviews.ToList())
        {
            if (!dtoIds.Contains(existing.ReviewId))
                _context.ProductReviews.Remove(existing);
        }

        foreach (var reviewDto in reviewsDto)
        {
            var existing = product.Reviews.FirstOrDefault(r => r.ReviewId == reviewDto.ReviewId);
            if (existing != null)
                _mapper.Map(reviewDto, existing);
            else
                product.Reviews.Add(_mapper.Map<ProductReview>(reviewDto));
        }

        await _context.SaveChangesAsync();
        return Ok();
    }


    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteProduct(Guid id)
    {
        var product = await _context.Products.FindAsync(id);

        if (product == null)
            return Ok();

        _context.Products.Remove(product);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}
