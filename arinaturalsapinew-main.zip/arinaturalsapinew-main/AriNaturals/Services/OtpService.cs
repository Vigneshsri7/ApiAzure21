﻿using System.Net;
using System.Security.Cryptography;
using AriNaturals.DataAccess;
using AriNaturals.Entity;
using AriNaturals.Interfaces;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.EntityFrameworkCore;
using MimeKit;

namespace AriNaturals.Services
{
    public class OtpService : IOtpService
    {
        private readonly AppDbContext _context;
        private readonly IConfiguration _config;

        public OtpService(AppDbContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        private string GenerateSecureOtp(int length)
        {
            const string digits = "0123456789";
            using var rng = RandomNumberGenerator.Create();
            var bytes = new byte[length];
            rng.GetBytes(bytes);
            return new string(bytes.Select(b => digits[b % digits.Length]).ToArray());
        }

        public async Task GenerateAndSendOtpAsync(string email, int length = 6, int expiryMinutes = 5)
        {
            // throttle: don't allow more than X OTPs in last Y minutes
            var recentCount = await _context.UserOtps
                .CountAsync(x => x.Email == email && x.CreatedAt > DateTime.UtcNow.AddMinutes(-1));
            if (recentCount >= 3) // small throttle - adjust to needs
                throw new InvalidOperationException("Too many OTP requests. Please try later.");

            var otp = GenerateSecureOtp(length);
            var expiry = DateTime.UtcNow.AddMinutes(expiryMinutes);

            // mark old unused otps as used to avoid reuse
            var old = await _context.UserOtps.Where(x => x.Email == email && !x.IsUsed).ToListAsync();
            old.ForEach(x => x.IsUsed = true);

            var record = new UserOtp
            {
                Email = email,
                OtpCode = otp,
                ExpiryTime = expiry,
                CreatedAt = DateTime.UtcNow,
                IsUsed = false
            };
            _context.UserOtps.Add(record);
            await _context.SaveChangesAsync();

            await SendEmailAsync(email, otp);
        }

        private async Task SendEmailAsync(string toEmail, string otp)
        {
            try
            {
                string fromEmail = _config["Email:From"];
                string password = _config["Email:Password"];
                string smtpHost = _config["Email:SmtpServer"] ?? "smtpout.secureserver.net";
                int smtpPort = int.Parse(_config["Email:Port"] ?? "465");

                var message = new MimeMessage();
                message.From.Add(new MailboxAddress("AriNaturals.com", fromEmail));
                message.To.Add(MailboxAddress.Parse(toEmail));
                message.Subject = "Your OTP Code";
                message.Body = new TextPart("plain") { Text = $"Your OTP is {otp}. This code expires in 5 minutes." };

                using var smtp = new SmtpClient();
                await smtp.ConnectAsync(smtpHost, smtpPort, SecureSocketOptions.SslOnConnect);
                await smtp.AuthenticateAsync(fromEmail, password);
                await smtp.SendAsync(message);
                await smtp.DisconnectAsync(true);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"General Error: {ex.Message}");
                if (ex.InnerException != null)
                    Console.WriteLine($"Inner: {ex.InnerException.Message}");
                throw ex;
            }

        }

        public async Task<bool> ValidateOtpAsync(string email, string otp)
        {
            var record = await _context.UserOtps
                .Where(x => x.Email == email && !x.IsUsed)
                .OrderByDescending(x => x.CreatedAt)
                .FirstOrDefaultAsync();

            if (record == null) return false;
            if (record.ExpiryTime < DateTime.UtcNow) return false;
            if (record.OtpCode != otp) return false;

            record.IsUsed = true;
            await _context.SaveChangesAsync();
            return true;
        }
    }

}
