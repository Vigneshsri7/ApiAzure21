﻿using AriNaturals.Interfaces;
using MailKit.Security;
using MimeKit;

namespace AriNaturals.Services
{
    public class EmailService : IEmailService
    {
        private readonly IConfiguration _config;
        private readonly string _siteName = "AriNaturals";
        private readonly string _logoUrl;

        public EmailService(IConfiguration config)
        {
            _config = config;
            _logoUrl = _config["Email:LogoUrl"];
        }

        public async Task SendEmailAsync(string to, string subject, string body)
        {
            string fromEmail = _config["Email:From"];
            string password = _config["Email:Password"];
            string smtpHost = _config["Email:SmtpServer"] ?? "smtpout.secureserver.net";
            int smtpPort = int.Parse(_config["Email:Port"] ?? "465");

            var message = new MimeMessage();
            message.From.Add(new MailboxAddress("AriNaturals.com", fromEmail));
            message.To.Add(MailboxAddress.Parse(to));
            message.Subject = subject;
            message.Body = new TextPart("html") { Text = body };

            using var smtp = new MailKit.Net.Smtp.SmtpClient();
            try
            {
                await smtp.ConnectAsync(smtpHost, smtpPort, SecureSocketOptions.SslOnConnect);
                await smtp.AuthenticateAsync(fromEmail, password);
                await smtp.SendAsync(message);
                await smtp.DisconnectAsync(true);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Email send failed: {ex.Message}");
                if (ex.InnerException != null)
                    Console.WriteLine($"Inner: {ex.InnerException.Message}");
                throw;
            }
        }

        public async Task<string> GenerateOrderEmail(
                                            string customerName,
                                            List<(string ItemName, string Measurement, int Quantity, decimal UnitPrice, string ImageUrl)> items,
                                            string shippingAddress)
        {
            // Calculate total dynamically
            decimal totalValue = items.Sum(i => i.UnitPrice * i.Quantity);

            var itemsHtml = string.Join("", items.Select(i => $@"
                                <tr>
                                    <td style='padding:8px;border:1px solid #ddd;'>
                                        <div style='display:flex; align-items:center;'>
                                            <div>
                                                <strong>{i.ItemName}</strong><br>
                                                <small>{i.Measurement}</small>
                                            </div>
                                        </div>
                                    </td>
                                    <td style='padding:8px;border:1px solid #ddd;text-align:right;'>{i.UnitPrice:C}</td>
                                    <td style='padding:8px;border:1px solid #ddd;text-align:center;'>{i.Quantity}</td>
                                    <td style='padding:8px;border:1px solid #ddd;text-align:right;'>{(i.UnitPrice * i.Quantity):C}</td>
                                </tr>
                            "));

            return $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset='UTF-8'>
                    <title>Order Confirmation</title>
                </head>
                <body style='font-family: Arial, sans-serif; background-color: #f8f8f8; margin:0; padding:0;'>
        
                    <!-- Header with logo -->
                    <div style='background-color:#232f3e; padding:10px; text-align:center; display:flex; align-items:center; justify-content:center;'>
                        <img src='{_logoUrl}' alt='{_siteName}' style='height:50px; margin-right:10px;'>
                        <span style='color:white; font-size:24px; font-weight:bold;'>{_siteName}</span>
                    </div>

                    <div style='max-width:600px; margin:20px auto; background:#fff; padding:20px; border-radius:8px;'>
                        <h2 style='color:#333;'>Thank you for your order, {customerName}!</h2>
                        <p>We’ve received your payment and your order is now being processed.</p>

                        <h3 style='margin-top:30px;'>Order Details</h3>
                        <table style='width:100%; border-collapse:collapse;'>
                            <thead>
                                <tr style='background:#f0f0f0;'>
                                    <th style='padding:8px;border:1px solid #ddd;text-align:left;'>Item</th>
                                    <th style='padding:8px;border:1px solid #ddd;text-align:right;'>Unit Price</th>
                                    <th style='padding:8px;border:1px solid #ddd;text-align:center;'>Qty</th>
                                    <th style='padding:8px;border:1px solid #ddd;text-align:right;'>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                {itemsHtml}
                                <tr>
                                    <td colspan='3' style='padding:8px;border:1px solid #ddd;text-align:right; font-weight:bold;'>Total</td>
                                    <td style='padding:8px;border:1px solid #ddd;text-align:right; font-weight:bold;'>{totalValue:C}</td>
                                </tr>
                            </tbody>
                        </table>

                        <h3 style='margin-top:30px;'>Shipping Address</h3>
                        <p style='white-space:pre-line; background:#f9f9f9; padding:10px; border:1px solid #ddd; border-radius:4px;'>{shippingAddress}</p>

                        <p style='margin-top:40px;'>If you have any questions, contact our support team.</p>
                        <p style='color:#999;font-size:12px;'>This is an automated email. Please do not reply directly to this message.</p>
                    </div>
                </body>
                </html>";
        }

    }
}
