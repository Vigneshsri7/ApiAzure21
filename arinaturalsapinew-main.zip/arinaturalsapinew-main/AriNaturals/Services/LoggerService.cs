﻿using AriNaturals.DataAccess;
using AriNaturals.Entity;
using AriNaturals.Interfaces;

namespace AriNaturals.Services
{
    public class LoggerService : ILoggerService
    {
        private readonly AppDbContext _context;
        private readonly ILogger<LoggerService> _logger;
        private readonly IHttpContextAccessor _http;

        public LoggerService(AppDbContext context, ILogger<LoggerService> logger, IHttpContextAccessor http)
        {
            _context = context;
            _logger = logger;
            _http = http;
        }

        public async Task LogAsync(Exception ex, string infoMessage = null, LogLevel logLevel = LogLevel.Error)
        {
            try
            {
                ErrorLog errorLog;
                if(ex == null)
                {
                    errorLog = new ErrorLog
                    {
                        Message = infoMessage,
                        StackTrace = null,
                        Source = GetCurrentAction(),
                        InnerException = null,
                        LogLevel = logLevel.ToString(),
                        ControllerName = GetCurrentController()
                    };
                }
                else
                {
                    errorLog = new ErrorLog
                    {
                        Message = ex.Message,
                        StackTrace = ex.StackTrace,
                        Source = GetCurrentAction(),
                        InnerException = ex.InnerException?.Message,
                        LogLevel = logLevel.ToString(),
                        ControllerName = GetCurrentController()
                    };
                }

               _context.ErrorLogs.Add(errorLog);
                await _context.SaveChangesAsync();
            }
            catch (Exception dbEx)
            {
                _logger.LogError(dbEx, "Failed to log error to database");
            }
        }

        #region Helper Method(s)
        public string? GetCurrentController()
        {
            return _http.HttpContext?
                .GetRouteData()?
                .Values["controller"]?.ToString();
        }

        public string? GetCurrentAction()
        {
            return _http.HttpContext?
                .GetRouteData()?
                .Values["action"]?.ToString();
        }
        #endregion
    }

}
