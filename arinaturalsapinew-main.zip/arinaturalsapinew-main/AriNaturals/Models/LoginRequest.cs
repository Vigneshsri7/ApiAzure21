﻿namespace AriNaturals.Models
{
    public record LoginRequest(string Email, string Password);
}
