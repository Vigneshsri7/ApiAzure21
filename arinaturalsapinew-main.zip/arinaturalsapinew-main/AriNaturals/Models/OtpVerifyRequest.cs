﻿namespace AriNaturals.Models
{
    public record OtpVerifyRequest(string Email, string Otp);
}
